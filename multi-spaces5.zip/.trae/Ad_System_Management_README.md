# 📢 DWH Crush APK - Ad System Management

## 🎯 ওভারভিউ

Ad System Management হলো DWH Crush APK এর একটি গুরুত্বপূর্ণ কম্পোনেন্ট যা বিজ্ঞাপন সিস্টেম নিয়ন্ত্রণ করে। এই সিস্টেমের মাধ্যমে Vungle বিজ্ঞাপন SDK disable করা, ad loading এবং playback control করা, এবং revenue tracking